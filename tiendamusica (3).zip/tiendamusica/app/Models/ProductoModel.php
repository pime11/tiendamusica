<?php

namespace App\Models;

use CodeIgniter\Model;

class ProductoModel extends Model
{
    protected $table = 'productos';
    protected $primaryKey = 'id';
    protected $allowedFields = ['categoria_id', 'nombre', 'artista', 'descripcion', 'precio', 'imagen', 'stock'];
    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    public function getProductosConCategoria()
    {
        return $this->select('productos.*, categorias.nombre as categoria_nombre')
                   ->join('categorias', 'categorias.id = productos.categoria_id')
                   ->findAll();
    }

    public function getProductosPorCategoria($categoria_id)
    {
        return $this->where('categoria_id', $categoria_id)->findAll();
    }
}