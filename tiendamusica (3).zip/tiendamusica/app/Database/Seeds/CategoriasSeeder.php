<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class CategoriasSeeder extends Seeder
{
    public function run()
    {
        // Deshabilitar verificación de claves foráneas
        $this->db->query('SET FOREIGN_KEY_CHECKS=0');
        
        // Primero vaciar la tabla productos que depende de categorías
        $this->db->table('productos')->truncate();
        // Luego vaciar la tabla carrito que depende de productos
        $this->db->table('carrito')->truncate();
        // Finalmente vaciar categorías
        $this->db->table('categorias')->truncate();
        
        // Habilitar verificación de claves foráneas
        $this->db->query('SET FOREIGN_KEY_CHECKS=1');

        $data = [
            ['id' => 1, 'nombre' => 'Rock', 'descripcion' => 'Rock clásico y moderno'],
            ['id' => 2, 'nombre' => 'Pop', 'descripcion' => 'Pop internacional'],
            ['id' => 3, 'nombre' => 'Jazz', 'descripcion' => 'Jazz tradicional y moderno'],
            ['id' => 4, 'nombre' => 'Clásica', 'descripcion' => 'Música clásica'],
            ['id' => 5, 'nombre' => 'Electrónica', 'descripcion' => 'EDM y música electrónica'],
            ['id' => 6, 'nombre' => 'J-Pop', 'descripcion' => 'Pop japonés con artistas como Atarashii Gakko y Ado'],
            ['id' => 7, 'nombre' => 'J-Rock', 'descripcion' => 'Rock japonés con grupos como Babymetal y Hanabie']
        ];

        $this->db->table('categorias')->insertBatch($data);
    }
}