<footer class="mt-5 py-4 bg-dark text-white">
            <div class="container text-center">
                <p class="mb-0">© <?= date('Y') ?> Tienda de Álbumes Musicales. Todos los derechos reservados.</p>
            </div>
        </footer>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
        <script>
            // Script para actualizar cantidades en el carrito
            document.querySelectorAll('.update-cart').forEach(button => {
                button.addEventListener('click', function(e) {
                    e.preventDefault();
                    const form = this.closest('form');
                    form.submit();
                });
            });
        </script>
    </body>
</html>