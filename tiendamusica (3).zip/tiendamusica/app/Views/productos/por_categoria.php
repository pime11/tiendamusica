<?= $this->include('templates/header') ?>

<div class="container">
    <h1 class="my-4">Álbumes en <?= esc($categoria['nombre']) ?></h1>
    
    <div class="row">
        <div class="col-md-3">
            <div class="card mb-4">
                <div class="card-header bg-primary text-white">
                    Categorías
                </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item">
                        <a href="<?= base_url('productos') ?>">Todos</a>
                    </li>
                    <?php foreach ($categorias as $cat): ?>
                    <li class="list-group-item <?= $cat['id'] == $categoria['id'] ? 'active' : '' ?>">
                        <a href="<?= base_url('productos/categoria/' . $cat['id']) ?>">
                            <?= esc($cat['nombre']) ?>
                        </a>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
        
        <div class="col-md-9">
            <?php if (empty($productos)): ?>
                <div class="alert alert-info">No hay álbumes en esta categoría.</div>
            <?php else: ?>
                <div class="row">
                    <?php foreach ($productos as $producto): ?>
                    <div class="col-md-4 mb-4">
                        <div class="card album-card h-100">
                            <img src="<?= base_url($producto['imagen']) ?>" 
                                 class="card-img-top" 
                                 alt="<?= esc($producto['nombre']) ?>"
                                 style="height: 250px; object-fit: cover">
                            <div class="card-body">
                                <h5 class="card-title"><?= esc($producto['nombre']) ?></h5>
                                <p class="card-text text-muted"><?= esc($producto['artista']) ?></p>
                                <p class="card-text"><strong>$<?= number_format($producto['precio'], 2) ?></strong></p>
                            </div>
                            <div class="card-footer bg-white">
                                <a href="<?= base_url('productos/' . $producto['id']) ?>" 
                                   class="btn btn-sm btn-outline-primary">
                                    Ver Detalles
                                </a>
                                <a href="<?= base_url('carrito/agregar/' . $producto['id']) ?>" 
                                   class="btn btn-sm btn-primary">
                                    Añadir al Carrito
                                </a>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?= $this->include('templates/footer') ?>