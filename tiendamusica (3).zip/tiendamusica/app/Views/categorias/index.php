<?= $this->include('templates/header') ?>

<div class="container my-4">
   
    
    <div class="row">
        <?php foreach ($categorias as $categoria): ?>
        <div class="col-md-4 mb-4">
            <div class="card h-100">
                <?php if(!empty($categoria['imagen'])): ?>
                <img src="<?= base_url('uploads/'.$categoria['imagen']) ?>" class="card-img-top" alt="<?= esc($categoria['nombre']) ?>">
                <?php endif; ?>
                <div class="card-body">
                    <h3 class="card-title"><?= esc($categoria['nombre']) ?></h3>
                    <p class="card-text">
                        <?= $categoria['total_productos'] ?> álbumes disponibles
                    </p>
                    <?php if(!empty($categoria['descripcion'])): ?>
                    <p class="card-text text-muted"><?= esc($categoria['descripcion']) ?></p>
                    <?php endif; ?>
                </div>
                <div class="card-footer bg-white d-flex justify-content-between">
                    <a href="<?= base_url('productos/categoria/'.$categoria['id']) ?>" 
                       class="btn btn-sm btn-outline-primary">
                        Ver Álbumes
                    </a>
                    
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<?= $this->include('templates/footer') ?>