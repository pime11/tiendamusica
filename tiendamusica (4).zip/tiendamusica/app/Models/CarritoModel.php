<?php

namespace App\Models;

use CodeIgniter\Model;

class CarritoModel extends Model
{
    protected $table = 'carrito';
    protected $primaryKey = 'id';
    protected $allowedFields = ['usuario_id', 'producto_id', 'cantidad'];
    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    public function getCarritoConProductos($usuario_id)
    {
        return $this->select('carrito.*, productos.nombre, productos.precio, productos.imagen')
                   ->join('productos', 'productos.id = carrito.producto_id')
                   ->where('carrito.usuario_id', $usuario_id)
                   ->findAll();
    }

    public function getTotalCarrito($usuario_id)
    {
        $items = $this->getCarritoConProductos($usuario_id);
        $total = 0;

        foreach ($items as $item) {
            $total += $item['precio'] * $item['cantidad'];
        }

        return $total;
    }
}