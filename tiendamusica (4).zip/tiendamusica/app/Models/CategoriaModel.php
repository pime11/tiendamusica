<?php

namespace App\Models;

use CodeIgniter\Model;




class CategoriaModel extends Model
{
    protected $table = 'categorias';
    protected $primaryKey = 'id';
    protected $allowedFields = ['nombre', 'imagen', 'descripcion'];
    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    public function getCategoriasConConteo()
    {
        return $this->select('categorias.*, COUNT(productos.id) as total_productos')
                   ->join('productos', 'productos.categoria_id = categorias.id', 'left')
                   ->groupBy('categorias.id')
                   ->findAll();
    }
}