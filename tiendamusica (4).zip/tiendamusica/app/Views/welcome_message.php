<?= $this->include('templates/header') ?>

<div class="hero-section">
    <div>
        <h1 class="hero-title">Bienvenido a ContinentalStore</h1>
        <p class="lead">La mejor selección de álbumes musicales</p>
        <a href="<?= base_url('productos') ?>" class="btn btn-primary btn-lg mt-3">Explorar Álbumes</a>
    </div>
</div>

<div class="container my-5">
    <div class="row">
        <!-- Novedades - Babymetal -->
        <div class="col-md-6 mb-4">
            <h2 class="mb-3">Novedades</h2>
            <div class="card h-100">
                <img src="<?= base_url('img/babymetal.jpeg') ?>" class="card-img-top" alt="Babymetal" style="height: 300px; object-fit: cover">
                <div class="card-body">
                    <h3 class="card-title">Megitsune</h3>
                    <p class="card-text text-muted">Babymetal</p>
                    <div class="d-flex justify-content-between align-items-center">
                        <h4 class="text-success">$55.23</h4>
                        <span class="badge bg-danger">Nuevo lanzamiento!</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Ofertas Especiales - Atarashii Gakko -->
        <div class="col-md-6 mb-4">
            <h2 class="mb-3">Ofertas Especiales</h2>
            <div class="card h-100">
                <img src="<?= base_url('img/atarashi.jpeg') ?>" class="card-img-top" alt="Atarashii Gakko" style="height: 300px; object-fit: cover">
                <div class="card-body">
                    <h3 class="card-title">Drama</h3>
                    <p class="card-text text-muted">Atarashii Gakko</p>
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <del class="text-muted">$44.99</del>
                            <h4 class="text-danger d-inline ms-2">$35.99</h4>
                        </div>
                        <span class="badge bg-warning text-dark">20% OFF</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?= $this->include('templates/footer') ?>  