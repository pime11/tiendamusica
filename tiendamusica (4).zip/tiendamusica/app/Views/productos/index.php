<?= $this->include('templates/header') ?>

    <div class="container">
        <h1 class="my-4">Nuestros Álbumes</h1>     
            <div class="col-md-9">
                <div class="row">
                    <?php foreach ($productos as $producto): ?>
                    <div class="col-md-4 mb-4">
                        <div class="card album-card h-100">
                            <img src="<?= esc($producto['imagen']) ?>" class="card-img-top" alt="<?= esc($producto['nombre']) ?>">
                            <div class="card-body">
                                <h5 class="card-title"><?= esc($producto['nombre']) ?></h5>
                                <p class="card-text text-muted"><?= esc($producto['artista']) ?></p>
                                <p class="card-text"><?= esc($producto['categoria_nombre']) ?></p>
                                <p class="card-text"><strong>$<?= number_format($producto['precio'], 2) ?></strong></p>
                            </div>
                            <div class="card-footer bg-white">
                                <a href="<?= base_url('productos/' . $producto['id']) ?>" class="btn btn-sm btn-outline-primary">Ver Detalles</a>
                                <a href="<?= base_url('carrito/agregar/' . $producto['id']) ?>" class="btn btn-sm btn-primary">Añadir al Carrito</a>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>

<?= $this->include('templates/footer') ?>