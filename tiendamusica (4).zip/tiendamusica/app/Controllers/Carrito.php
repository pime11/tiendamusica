<?php

namespace App\Controllers;

use App\Models\CarritoModel;
use App\Models\ProductoModel;

class Carrito extends BaseController
{
    protected $carritoModel;
    protected $productoModel;
    protected $usuario_id;

    public function __construct()
    {
        $this->carritoModel = new CarritoModel();
        $this->productoModel = new ProductoModel();
        $this->usuario_id = 1; // ID temporal para pruebas
    }

    public function index()
    {
        $data = [
            'items' => $this->carritoModel->getCarritoConProductos($this->usuario_id),
            'total' => $this->carritoModel->getTotalCarrito($this->usuario_id),
        ];

        return view('carrito/index', $data);
    }

    public function agregar($producto_id)
    {
        $producto = $this->productoModel->find($producto_id);

        if (!$producto) {
            return redirect()->back()->with('error', 'Producto no encontrado');
        }

        $item = $this->carritoModel->where('usuario_id', $this->usuario_id)
                                  ->where('producto_id', $producto_id)
                                  ->first();

        if ($item) {
            $this->carritoModel->update($item['id'], [
                'cantidad' => $item['cantidad'] + 1,
            ]);
        } else {
            $this->carritoModel->save([
                'usuario_id' => $this->usuario_id,
                'producto_id' => $producto_id,
                'cantidad' => 1,
            ]);
        }

        return redirect()->to('/carrito')->with('success', 'Producto agregado al carrito');
    }

    public function actualizar($id)
    {
        $item = $this->carritoModel->find($id);

        if (!$item || $item['usuario_id'] != $this->usuario_id) {
            return redirect()->to('/carrito')->with('error', 'Ítem no encontrado');
        }

        $cantidad = $this->request->getPost('cantidad');

        if ($cantidad <= 0) {
            $this->eliminar($id);
        } else {
            $this->carritoModel->update($id, [
                'cantidad' => $cantidad,
            ]);
        }

        return redirect()->to('/carrito')->with('success', 'Carrito actualizado');
    }

    public function eliminar($id)
    {
        $item = $this->carritoModel->find($id);

        if (!$item || $item['usuario_id'] != $this->usuario_id) {
            return redirect()->to('/carrito')->with('error', 'Ítem no encontrado');
        }

        $this->carritoModel->delete($id);

        return redirect()->to('/carrito')->with('success', 'Producto eliminado del carrito');
    }

    // Nuevo método para procesar el pago
    public function procesarPago()
    {
        $items = $this->carritoModel->where('usuario_id', $this->usuario_id)->findAll();
        
        if(empty($items)) {
            return redirect()->to('/carrito')->with('error', 'El carrito está vacío');
        }
        
        // Lógica de pago (simulada)
        $this->carritoModel->where('usuario_id', $this->usuario_id)->delete();
        
        return redirect()->to('/carrito')->with('success', '¡Compra realizada exitosamente!');
    }
}